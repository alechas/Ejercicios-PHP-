<html>

<head>
	<title>
		Final
	</title>
</head>

<body>
	
	<form action="login.php" method="post">

	<input type="submit" value="Cargar">

	</form>

</body>

</html>